$(document).ready(function(){
	$("#cnic").keyup(function(){
		var cnics=$("#cnic").val();
		if(cnics.length!=13){
			reset_field();
		}else{
			//
			// call ajax
			$.ajax({
				url:"../controller/Token_Controller.php",
				type:"POST",
				data:{action:"get_data",cnic:cnics},
				
				success:function(content){
					var token=JSON.parse(content);
					if(token.id==0){
						$("#response").html(" New Patient");
					}else{
						$("#response").html(" Old Patient");
						//console.log(content);
						//var json_obj=JSON.parse(content);
						
						$("#patient_name").val(token.patient_name);
						//alert(token.patient_name);
						$("#father_or_husband_name").val(token.father_or_husband_name);
						$("#address").val(token.address);
						$("#phone").val(token.phone);
					}

					
					// setTimeout(function(){
					// 	$("#wait").fadeIn();
					// 	$("#wait").removeClass("alert alert-info").html("");
					// },5000);

				}
			});
		}
	});
	function reset_field(){
		$("#patient_name").val("");
		$("#father_or_husband_name").val("");
		$("#address").val("");
		$("#phone").val("");
		$("#response").html("");
	}
});