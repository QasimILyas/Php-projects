<?php

// this class connect connection 
class Connection_DB
{
    private $connect;
    // initial object
    public function __construct()
    {

        $this->connect=mysqli_connect("localhost","root","","hospital_token_system");
    }
    // get connection resource
    public function get_connection()
    {
        return $this->connect;
    }
    // destructor
    public function __destruct()
    {
     mysqli_close($this->connect);
    }
    
    
}// END CLASS

?>