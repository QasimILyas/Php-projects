<?php
//print_r($_POST);
/*--------------------------------------------------------------------------------------
include file references
--------------------------------------------------------------------------------------*/
require_once("../config/Connection_DB.php");
require_once("../model/Token_Model.php");
require_once("../helper/session_functions.php");

set_session();
/*--------------------------------------------------------------------------------------
create database connection
create question paper and paper classes objects
--------------------------------------------------------------------------------------*/
$connect_db=new Connection_DB();
$connection=$connect_db->get_connection();
$token= new Token_Model($connection);


/*--------------------------------------------------------------------------------------
create_token
--------------------------------------------------------------------------------------*/
if(isset($_POST["save_token"])){
	
	// get prementers
	$cnic=string_check($_POST["cnic"]);
	$patient_name=string_check($_POST["patient_name"]);
	$father_or_husband_name=string_check($_POST["father_or_husband_name"]);
	$address=string_check($_POST["address"]);
	$phone=string_check($_POST["phone"]);
	$user_id=get_value_of_current_user($_GET["key"],"user_id");
	$token->add_token($cnic,$patient_name,$father_or_husband_name,$address,$phone,$user_id);
	$_SESSION["success"]="New Token Generated Successfully.";
	if(isset($_GET["key"])){
		$url="Location: ../view/home.php?&key=".$_GET["key"];
	}

	
header($url);


}
if(isset($_POST["action"])){
	
	// get prementers
	$cnic=string_check($_POST["cnic"]);
	unset($_POST["cnic"]);
	$record=$token->get_data($cnic);
	if(mysqli_num_rows($record)>0){
		//echo "Database";
		$row=mysqli_fetch_assoc($record);
		$obj=new stdClass();
		$obj->cnic=$row["cnic"];
		$obj->patient_name=$row["patient_name"];
		$obj->father_or_husband_name=$row["father_or_husband_name"];
		$obj->address=$row["address"];
		$obj->phone=$row["phone"];
		
		echo json_encode($obj);
	}else{
		echo json_encode(array("id"=>"0"));
		//echo "New Patient";
	}


}


if(isset($_GET["report_print"])){
	$url="../view/report_print.php?key=".$_GET["key"]."&date=".$_GET["date"];
	header("Location: $url");
}	
if(isset($_GET["report"])){
	$url="../view/report.php?key=".$_GET["key"];
	header("Location: $url");
}
if(isset($_GET["token_id"])){
	$url="../view/receipt.php?key=".$_GET["key"]."&id=".$_GET["token_id"];
	header("Location: $url");
}	
if(isset($_POST["print"])){
	
	// get prementers
	$start_date=string_check($_POST["start_date"]);
	$end_date=string_check($_POST["end_date"]);
	$url="Location: ../view/report_print.php?&key=".$_GET["key"]."&start_date=$start_date&end_date=$end_date";
	header($url);


}
?>