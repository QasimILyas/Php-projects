<?php

// include file references
require_once("../config/Connection_DB.php");
require_once("../model/User_Model.php");
require_once("../helper/session_functions.php");

set_session();
?>
<?php
$connect_db=new Connection_DB();
$connection=$connect_db->get_connection();
$user= new User_Model($connection);
// login all user

if(isset($_POST["log_in"])){
	
	echo $user_name=string_check($_POST["user_name"]);
    $password=string_check($_POST["password"]);
	$password=md5($password);
	$is_login=$user->login($user_name,$password);
	$error_message="";
	if(mysqli_num_rows($is_login)==1)
	{
		$record=mysqli_fetch_assoc($is_login);
			
		 $id=$record["id"];
		 $is_unique_user=is_unique_user($id);
		if($is_unique_user==0){
		
			$key=md5($id);
			
			$user_name=$record["name"];
			$user_data=array(
			'user_id'=>$id,
			'user_name'=>$user_name,
			
			);
			
			if(!isset($_SESSION["user_data"])){
				$_SESSION["user_data"][$key]=$user_data;
			}else{
			$_SESSION["user_data"][$key]=$user_data;
			}

			
		}else{
			$key=$is_unique_user;
		}
		//
			header("Location:  ../view/home.php?key=$key");
	}else{
		$error_message="user name or password may be wrong.";
		setcookie("wrong", $error_message, time() +  1, "/");
		header("Location: ../view/index.php");
	}
	// 
	}
	
	// dashboard
	if(isset($_GET['home']) or isset($_GET['cancel'])){
		if(isset($_GET['key'])){
			$user_key=$_GET['key'];
			header("Location:  ../view/home.php?key=$user_key");
		}else{
			header("Location:  ../view/index.php");
		}	
	}
	// logout 
	if(isset($_GET['logout'])){
		$user_key=$_GET["key"];
		distory_user_session($user_key);
		header("Location: ../view/index.php"); 
	}
	// view login page
	if(isset($_GET['login'])){
		header("Location: ../view/index.php");
	}
	// view register page
	if(isset($_GET['register'])){
		header("Location: ../view/register.php");
	}
		// add new user
	if(isset($_POST["registration"])){
		
		$user_name=strtolower(string_check($_POST["user_name"]));
		$record=$user->get_user_name($user_name);
		// check user name is unique or not
		if(mysqli_num_rows($record)>=1)
		{
			$error_message=$_POST["user_name"]." user already exist.";
			
			setcookie("wrong", $error_message, time() +  1, "/");
			header("Location: ../view/register.php");
			exit;
		}
		
		$password=string_check($_POST["password"]);
		$password=md5($password);
		$user->add_new_user($user_name,$password);
		
		$error_message="your account create is Successfuly";
		
		setcookie("success", $error_message, time() +  30, "/");
		header("Location: ../view/register.php");
	}
	
	
?>