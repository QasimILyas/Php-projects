-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 14, 2020 at 12:55 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital_token_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `token`
--

CREATE TABLE `token` (
  `id` int(5) NOT NULL,
  `user_id` int(5) DEFAULT NULL,
  `cnic` varchar(15) NOT NULL,
  `patient_name` text NOT NULL,
  `father_or_husband_name` text NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(12) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `token`
--

INSERT INTO `token` (`id`, `user_id`, `cnic`, `patient_name`, `father_or_husband_name`, `address`, `phone`, `creation_date`) VALUES
(1, 4, '3540420040050', 'Ali', 'khan', 'skp', '03219856421', '2020-11-14 07:07:53'),
(2, 4, '3540411111111', 'mohsin ali', 'M Shabbir', 'Sheikhupura', '03008898691', '2020-11-14 07:07:53'),
(3, 4, '3540411111112', 'atta mohsin', 'mohsin', 'Lahore', '03028064424', '2020-11-14 07:07:53'),
(4, 4, '3540425642231', 'Aaban', 'Abdul Hakam', 'Lahore', '03245042351', '2020-11-14 07:07:53'),
(5, 4, '3540425642232', 'Aabid', 'Abdul Hafiz', 'Lahore', '03245042352', '2020-11-14 07:07:53'),
(6, 4, '3540425642233', 'Aadil', 'Abdul Hafeez', 'Lahore', '03245042353', '2020-11-14 07:07:53'),
(7, 4, '3540425642234', 'Aahil', 'Abdul Ghafoor', 'Lahore', '03245042354', '2020-11-14 07:07:53'),
(8, 4, '3540425642235', 'Aalam', 'Abdul Ghafaar', 'Lahore', '03245042355', '2020-11-14 07:07:53'),
(9, 4, '3540425642236', 'Aalee', 'Abdul Fattah', 'Lahore', '03245042356', '2020-11-14 07:07:53'),
(10, 4, '3540425642237', 'Aalim', 'Abdul Batin', 'Lahore', '03245042357', '2020-11-14 07:07:53'),
(11, 4, '3540425642238', 'Aamil', 'Abdul Basit', 'Lahore', '03245042358', '2020-11-14 07:07:53'),
(12, 4, '3540425642239', 'Aamir', 'Abdul Baseer', 'Lahore', '03245042359', '2020-11-14 07:07:53'),
(13, 4, '3540425642240', 'Aaqib', 'Abdul Bari', 'Lahore', '03245042360', '2020-11-14 07:07:53'),
(14, 4, '3540425642241', 'Aaqil', 'Abdul Baqi', 'Lahore', '03245042361', '2020-11-14 07:07:53'),
(15, 4, '3540425642242', 'Aarif', 'Abdul Baith', 'Lahore', '03245042362', '2020-11-14 07:07:53'),
(16, 4, '3540425642243', 'Abdul Aalee', 'Abdul Badee', 'Lahore', '03245042363', '2020-11-14 07:07:53'),
(17, 4, '3540425642244', 'Abdul Adl', 'Abdul Baasit', 'Lahore', '03245042364', '2020-11-14 07:07:53'),
(18, 4, '3540425642245', 'Abdul Afuw', 'Abdul Baari', 'Lahore', '03245042365', '2020-11-14 07:07:53'),
(19, 4, '3540425642246', 'Abdul Ahad', 'Abdul Aziz', 'Lahore', '03245042366', '2020-11-14 07:07:53'),
(20, 4, '3540425642247', 'Abdul Aleem', 'Abdul Azim', 'Lahore', '03245042367', '2020-11-14 07:07:53'),
(21, 4, '3540425642248', 'Abdul Alim', 'Abdul Azeez', 'Lahore', '03245042368', '2020-11-14 07:07:53'),
(22, 4, '3540425642249', 'Abdul Awwal', 'Abdul Awwal', 'Lahore', '03245042369', '2020-11-14 07:07:53'),
(23, 4, '3540425642250', 'Abdul Azeez', 'Abdul Alim', 'Lahore', '03245042370', '2020-11-14 07:07:53'),
(24, 4, '3540425642251', 'Abdul Azim', 'Abdul Aleem', 'Lahore', '03245042371', '2020-11-14 07:07:53'),
(25, 4, '3540425642252', 'Abdul Aziz', 'Abdul Ahad', 'Lahore', '03245042372', '2020-11-14 07:07:53'),
(26, 4, '3540425642253', 'Abdul Baari', 'Abdul Afuw', 'Lahore', '03245042373', '2020-11-14 07:07:53'),
(27, 4, '3540425642254', 'Abdul Baasit', 'Abdul Adl', 'Lahore', '03245042374', '2020-11-14 07:07:53'),
(28, 4, '3540425642255', 'Abdul Badee', 'Abdul Aalee', 'Lahore', '03245042375', '2020-11-14 07:07:53'),
(29, 4, '3540425642256', 'Abdul Baith', 'Aarif', 'Lahore', '03245042376', '2020-11-14 07:07:53'),
(30, 4, '3540425642257', 'Abdul Baqi', 'Aaqil', 'Lahore', '03245042377', '2020-11-14 07:07:53'),
(31, 4, '3540425642258', 'Abdul Bari', 'Aaqib', 'Lahore', '03245042378', '2020-11-14 07:07:53'),
(32, 4, '3540425642259', 'Abdul Baseer', 'Aamir', 'Lahore', '03245042379', '2020-11-14 07:07:53'),
(33, 4, '3540425642260', 'Abdul Basit', 'Aamil', 'Lahore', '03245042380', '2020-11-14 07:07:53'),
(34, 4, '3540425642261', 'Abdul Batin', 'Aalim', 'Lahore', '03245042381', '2020-11-14 07:07:53'),
(35, 4, '3540425642262', 'Abdul Fattah', 'Aalee', 'Lahore', '03245042382', '2020-11-14 07:07:53'),
(36, 4, '3540425642263', 'Abdul Ghafaar', 'Aalam', 'Lahore', '03245042383', '2020-11-14 07:07:53'),
(37, 4, '3540425642264', 'Abdul Ghafoor', 'Aahil', 'Lahore', '03245042384', '2020-11-14 07:07:53'),
(38, 4, '3540425642265', 'Abdul Hafeez', 'Aadil', 'Lahore', '03245042385', '2020-11-14 07:07:53'),
(39, 4, '3540425642266', 'Abdul Hafiz', 'Aabid', 'Lahore', '03245042386', '2020-11-14 07:07:53'),
(40, 4, '3540425642267', 'Abdul Hakam', 'Aaban', 'Lahore', '03245042387', '2020-11-14 07:07:53');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `password`) VALUES
(1, 'ali', '81dc9bdb52d04dc20036dbd8313ed055'),
(4, 'admin', '21232f297a57a5a743894a0e4a801fc3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `token`
--
ALTER TABLE `token`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `token`
--
ALTER TABLE `token`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
