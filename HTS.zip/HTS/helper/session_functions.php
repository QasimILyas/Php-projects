<?php
function string_check($string)
{
    $string=trim($string);
	$string=htmlspecialchars($string);
	$string=stripslashes($string);
	return $string;
}
// helper functions on session 
function is_unique_user($user_id){
	$user_data=$_SESSION["user_data"];
	if(isset($user_data)){
		foreach($user_data as $keys=>$value){
			if($value["user_id"]==$user_id){
				return $keys;
			}
		}
		return 0;
	}else{
		return 0;
	}
}
function get_value_of_current_user($user_key,$key){

	
	if(isset($_SESSION["user_data"][$user_key][$key])){
		$value=$_SESSION["user_data"][$user_key][$key];
		return $value;
	}else{
		return null;
	}
	
}
function is_login($user_key,$key){

	
	if(isset($_SESSION["user_data"][$user_key][$key])){
		
		return true;
	}else{
		return false;
	}
	
}
function distory_user_session($user_key){
	unset($_SESSION["user_data"][$user_key]);
	$count=count($_SESSION["user_data"]);
	if($count==0){
	
		unset($_SESSION["user_data"]);
	}
}

function set_value_of_current_user($user_key,$key,$value){
	$_SESSION["user_data"][$user_key][$key]=$value;

}
function set_session(){
	if(!isset($_SESSION))
	{
		session_start();
	}
}
function display_session_message(){
	
	if(isset($_SESSION["wrong"])){
		echo "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
		echo "<div class='alert alert-danger text-capitalize alert-dismissible'> ". $_SESSION["wrong"]."</div>";
		unset($_SESSION["wrong"]);
									   
	 }else if(isset($_SESSION["success"])){
	 	echo "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";echo "<div class='alert alert-success text-capitalize alert-dismissible'> ". $_SESSION["success"]."</div>";
		unset($_SESSION["success"]);
									   
	 }
	

}
function display_feedback_message(){
	
	if(isset($_COOKIE["wrong"])){
		echo "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";echo "<div class='alert alert-danger text-capitalize alert-dismissible'> ". $_COOKIE["wrong"]."</div>";
		setcookie("wrong", '', time() +  30, "/");
									   
	 }else if(isset($_COOKIE["success"])){
	 	echo "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";echo "<div class='alert alert-success text-capitalize alert-dismissible'> ". $_COOKIE["success"]."</div>";
		setcookie("success", '', time() +  30, "/");
									   
	 }
	

}

?>