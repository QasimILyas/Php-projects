<?php
 class Token_Model{
	private $connection;
	public function __construct($connection_db){
	$this->connection=$connection_db;
	}
	
	public function add_token($cnic,$patient_name,$father_or_husband_name,$address,$phone,$user_id){
		$sql="INSERT INTO token(cnic,patient_name,father_or_husband_name,address,phone,user_id)"; 	
		$sql.=" VALUES('$cnic','$patient_name','$father_or_husband_name','$address','$phone',$user_id)";
		mysqli_query($this->connection,$sql);
	}
    public function get_data($cnic){
        
       
        $sql="SELECT * FROM token ";
        $sql.="where cnic ='$cnic' limit 1 ";
         return $result_set=mysqli_query($this->connection,$sql);
          
    }
	private function query(){
		
		$date=date("Y-m-d");
		$sql="SELECT * FROM token ";
		$sql.="where creation_date like'$date%' order by creation_date desc ";
		return $sql;
	}
	private function view_all_record(){
        //echo date_default_timezone_get();
		$sql=Token_Model::query();
		$result_set=mysqli_query($this->connection,$sql);
		return $result_set;
	}
	private function view_all_record_by_limit($start,$limit){
		$sql=Token_Model::query();
		$sql.="limit $start,$limit ";
		$result_set=mysqli_query($this->connection,$sql);
		return $result_set;
	}
	public function display_record($key)
    {   
    	
        // start table and header
        echo "<div ><table class='table table-bordered table-striped'>
        <thead>";
        $columns=7;
        // first show limit list
        if(!isset($_GET["start"]))
        {
            $start=0;
        }
        if(isset($_GET["start"]))
        {
			$start=$_GET["start"];
        }	

        $limit=6;
        $page_name=$_SERVER["PHP_SELF"];
        $result_set=Token_Model::view_all_record();
        $record_lines=mysqli_num_rows($result_set);
        $result=Token_Model::view_all_record_by_limit($start,$limit);
		echo "<tr>";
			echo "<th colspan='2'> <h3>Total Token No: ".$record_lines."</h3></th>";
            echo "<th colspan='2'> <h3>".OFFICE_NAME."</h3></th>";
            echo "<th colspan='2'><a href='../controller/Token_Controller.php?report_print=1&key=$key&date=".date("Y-m-d")."'
            class='btn btn-info'>Print Report</a></th>";
 		echo"</tr>";
        // display heading data
        echo "<tr>";
			
			echo "<th> Token No</th>";
			echo "<th style='text-transform:capitalize;'>CNIC</th>";
			echo "<th style='text-transform:capitalize;'>Patient Name</th>";
			echo "<th style='text-transform:capitalize;'>Father/Husband Name</th>";
			echo "<th style='text-transform:capitalize;'>Phone</th>";
			echo "<th style='text-transform:capitalize;'>Actions</th>";
			
 		echo"</tr>
        
        </thead>
        
        <tbody>";
        
        
        
        if($record_lines<=0)
        {
            echo "<tr><td colspan='".$columns."'>"; 
            echo "<b><center>No Record Found</center></b>";
            echo "</td> </tr>";
        }
        else
        {
            $count=$start;
            while($row=mysqli_fetch_assoc($result)){
            ++$count;
            //show data in table
            echo "<tr>
                    <td>".$row['id']."</td>";
                    echo "<td>".$row['cnic']."</td>
                    	 <td>".$row['patient_name']."</td>
                    	 <td>".$row['father_or_husband_name']."</td>
                    	  <td>".$row['phone']."</td>
                    	<td ><a href='../controller/Token_Controller.php?token_id=".$row["id"]."&key=".$key."' class='btn btn-info'> Print </a></td>";
                   
            echo"</tr>";
            }
        }
        //printing page numbers as bar
         
        echo "</tbody>";
        // Pagination code call
        Token_Model::Pagination($record_lines,$columns,$start,$limit,$page_name,$key);
        
    
    echo "</table></div>";    

    }// end of function

    public function display_report($key,$strat_date,$end_date)
    {   
        
        // start table and header
        echo "<div ><table class='table'>  <thead>";
        $sql="select u.name,t.id,t.patient_name,t.father_or_husband_name,t.cnic,t.address,t.phone,t.creation_date
         from token t, users u where (creation_date between '$strat_date' and '$end_date' ) and u.id=t.user_id";
        $result_set=mysqli_query($this->connection,$sql);
       
        $record_lines=mysqli_num_rows($result_set);
        echo "<tr>";
            echo "<th colspan='7' style='text-align:center' class='no_border'> <h2>".OFFICE_NAME."</h2></th>";
           
        echo"</tr>";
        echo "<tr>";
            echo "<th colspan='6' class='no_border'> <h4>Print Date: <span>"
            .date('d M Y')."</span></h4></th>";
           
        echo"</tr>";
        echo "<tr>";
            echo "<th colspan='6' class='no_border'> <h4>Total Token No: ".$record_lines."</h4></th>";
        echo"</tr>";
        echo"</tr>";
            echo "<th colspan='6' class='no_border'> </th>";
         echo "<tr>";

        // display heading data
        echo "<tr>";
            echo "<th> Serial No</th>";
            echo "<th> Token No</th>";
            echo "<th style='text-transform:capitalize;'>CNIC</th>";
            echo "<th style='text-transform:capitalize;'>Patient Name</th>";
            echo "<th style='text-transform:capitalize;'>Father/Husband Name</th>";
            echo "<th style='text-transform:capitalize;'>Phone</th>";
            echo "<th style='text-transform:capitalize;'>Clerk Name</th>";
            echo "<th style='text-transform:capitalize;'>Posting Date</th>";
        echo"</tr>
        
        </thead>
        
        <tbody>";
        
        
        
        if($record_lines<=0)
        {
            echo "<tr><td colspan='7'>"; 
            echo "<b><center>No Record Found</center></b>";
            echo "</td> </tr>";
        }
        else
        {
            $count=0;
            while($row=mysqli_fetch_assoc($result_set)){
            ++$count;
            //show data in table
            $date=date_create($row['creation_date']);
            $date=date_format($date,"d M Y ");
            echo "<tr>
                    <td>".$count."</td>
                    <td>".$row['id']."</td>";
                    echo "<td>".$row['cnic']."</td>
                         <td>".$row['patient_name']."</td>
                         <td>".$row['father_or_husband_name']."</td>
                          <td>".$row['phone']."</td>
                          <td>".$row['name']."</td>
                          <td>".$date."</td>";
                   
            echo"</tr>";
            }
        }

         echo "<tr>";
            echo "<th colspan='2'> <h4>Print Date: <span >".date('d M Y')."</span></h4></th>";
            echo "<th colspan='2'> </th>";
            echo "<th colspan='2' > <h4>Signature : <span style='border-bottom:1px dashed black;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></h4></th>";
           
        echo"</tr>";
         
        echo "</tbody>";
        
    
    echo "</table></div>";    

    }// end of function

     public function Pagination($record_lines,$columns,$start,$limit,$page_name,$key){
        if($record_lines>0){
            echo "<tfoot>
            <td colspan='".$columns."'>
            
                <div class='pull-right'>
                    <ul class='pagination'>
                      <li class='previous'><a href='$page_name?start=0&key=$key'>First</a></li>";
                        $current_page; $total_pages;$j=1;
                        for ($i =0; $i<$record_lines;$i=$i+$limit)
                        {
                            if($i<> $start)
                            {
                                echo "<li><a href='$page_name?start=$i&key=$key'> $j</a></li>";
                              
                            }else{
                                echo "<li class='active'><a href='#&key=$key'>$j</a></li>";
                                $current_page=$j;
                            }
                            $j++;
                       }
                      $total_pages=ceil($record_lines/$limit);
                      $last=$i-$limit;
                      echo "<li class='next'><a href='$page_name?start=$last&key=$key'>Last</a></li>
                    </ul>
                    
                </div>
                <div class='pull-left'>
                    <br>
                    <p style='margin-top:2px'>";
                        if($current_page>=1){
                        echo $current_page." pages of ".$total_pages;
                        }else{
                        echo "1 page of 1";
                        }
                    echo "</p>
                </div>
            </td>
        </tfoot>";
		}
	}// end of pagination function

	function display_form($submit_name,$submit_value,$name,$query_string,$key){

		echo "<div class='panel panel-default'>
            
			<div class='panel-heading'><h3>".$name."</h3></div>
			<div class='panel-body'>
            <p id='wait'></p>
			<form action='../controller/Token_Controller.php$query_string' method='post' id='token_form'>
				<div class='form-group'>
					<label for='cnic'>CNIC: <span id='response'></span></label>
					<input type='type' pattern='[0-9\s]+' title='only characters allowed' maxLength='13' placeholder='Enter Patient CNIC Without Dash' name='cnic' class='form-control' id='cnic' required />
				</div>
				<div class='form-group'>
					<label for='patient_name'>Patient Name:</label>
					<input type='type' pattern='[a-zA-Z\s]+' title='only characters allowed'  placeholder='Enter Patient Name' name='patient_name' id='patient_name' class='form-control' required />
				</div>
				<div class='form-group'>
					<label for='father_or_husband_name'>Father/Husband Name:</label>
					<input type='type' pattern='[a-zA-Z\s]+' title='only characters allowed'  placeholder='Enter Patient Father/ Husband Name' name='father_or_husband_name' id='father_or_husband_name' class='form-control' required />
				</div>

				<div class='form-group'>
					<label for='address'>Address:</label>
					<input type='type' pattern='[a-zA-Z\s]+' title='only characters allowed'  placeholder='Enter Patient Address' name='address' id='address' class='form-control' required />
				</div>

				<div class='form-group'>
					<label for='phone'>Phone:</label>
					<input type='type' pattern='[0-9\s]+' title='only characters allowed'  placeholder='Enter Patient phone  Without Dash' name='phone' id='phone' class='form-control' maxLength='11' required />
				</div>

				<div class='form-group'>
			<input type='submit' class='btn btn-primary ' name='".$submit_name."' value='".$submit_value."' id='save_token' />";
		
				echo "<a href='../controller/User_Controller.php?cancel=1&key=$key' class='btn btn-danger ' style='margin-left:15px;'
				>Cancel</a>
			</div>
			</form>
			</div>
		</div>";
	}

    function display_report_form($submit_name,$submit_value,$name,$query_string,$key){

        echo "<div class='panel panel-default'>
            
            <div class='panel-heading'><h3>".$name."</h3></div>
            <div class='panel-body'>
            <p id='wait'></p>
            <form action='../controller/Token_Controller.php$query_string' method='post' >
                <div class='form-group'>
                    <label >Start Date</label>
                    <input type='date' name='start_date' class='form-control' required />
                </div>
                <div class='form-group'>
                    <label >End Date</label>
                    <input type='date' name='end_date' class='form-control' required />
                </div>

                <div class='form-group'>
                <input type='submit' class='btn btn-primary ' name='".$submit_name."' value='".$submit_value."'  />";
        
                echo "<a href='../controller/User_Controller.php?cancel=1&key=$key' class='btn btn-danger ' style='margin-left:15px;'
                >Cancel</a>
            </div>
            </form>
            </div>
        </div>";
    }
    function display_receipt($key,$id){
        //$sql="select * from token where id='$id' ";
        $sql="select u.name,t.id,t.patient_name,t.father_or_husband_name,t.cnic,t.address,t.phone,t.creation_date
         from token t, users u where u.id=t.user_id limit 1";
       
        $result=mysqli_query($this->connection,$sql);
        $token=mysqli_fetch_assoc($result);

        $date=date_create($token['creation_date']);
            $date=date_format($date,"d M Y h:i:s ");
        echo "<div class='panel panel-default'>
            
            <h3 style='text-align:center;margin-top:30px;'>".OFFICE_NAME."</h3>
            <div class='panel-body'>
                <div style='text-align:center;'>
                    <h4>Receipt Date</h4>
                    <h4>".$date."</h4>
                    <h4>Clerk Name</h4>
                    <h4>".$token["name"]."</h4>
                    <hr/>
                    <h3>Token#</h3>
                    <h4>".$token["id"]."</h4>
                    <h4>Name: ".$token["patient_name"]."</h4>
                    <h4>S/O & W/O: ".$token["father_or_husband_name"]."</h4>
                    <h4>CNIC: ".$token["cnic"]."</h4>
                    <h4>Address: ".$token["address"]."</h4>

                    <h4>Phone: ".$token["phone"]."</h4>

                    <hr/>
                    <h4>Thank you come again! </h4>
                    <h5>Dedicated To My Father </h5>
                    <h5>ILYAS AHMAD</h5>
                    <h5>DESIGN AND DEVELOPED BY</h5>
                    <h5>MUHAMMAD QASIM </h5>
                    <h5>CONTACT US:  0323-0479048</h5>
                </div>
            </div>
        </div>";
    }
}
?>
