<?php
class User_Model{
	private $connection;
	public function __construct($connection_db){
	$this->connection=$connection_db;
	}
	public function login($user_name,$password){
		$sql="select * from users where ";
		$sql.="name='$user_name' and password='$password'";
		$result_set=mysqli_query($this->connection,$sql);
		return $result_set;
	}
	
	public function get_user_name($user_name){
	$sql="select name from users where ";
	echo $sql.="name = '$user_name' limit 1";
	$result_set=mysqli_query($this->connection,$sql);
	
	return $result_set;
	}
	public function add_new_user($name,$password){
		$sql="INSERT INTO users(name,password)"; 	
		$sql.=" VALUES('$name','$password')";
		echo $sql;//exit;
		mysqli_query($this->connection,$sql);
		
	}
	
// display form
	
function display_form($submit_name,$submit_value,$name){
		
		echo "
			<h2>".$name."</h2>
			<form action='../controller/User_Controller.php' method='post'>
				<div class='form-group'>
					<label for='user_name'>User Name:</label>
					<input type='type' pattern='[a-zA-Z\s]+' title='only characters allowed' maxLength='32' placeholder='Enter Your Name' name='user_name' class='form-control' required />
				</div>
				<div class='form-group'>
					<label for='password'>Password:</label>
					<input type='password' placeholder='Password' name='password' class='form-control' pattern='[ a-zA-Z0-9]+' title='only characters and numbers allowed' maxLength='32' required />
				</div>
				<div class='form-group'>
			<input type='submit' class='btn btn-primary form-control' name='".$submit_name."' value='".$submit_value."' />";
		
				echo "<a href='../controller/User_Controller.php?cancel=1' class='btn btn-danger form-control' style='margin-top:15px;'
				>Cancel</a>
			</div>
			</form>";
	}
	

}
?>