## Dedicated To My Father ILYAS AHMAD

## DESIGN AND DEVELOPED BY MUHAMMAD QASIM 

## CONTACT US: 0323-0479048

## HTS is a Hospital Token System.
## Configuration 
## Create DATABASE
## Import SQL file
## Create User Account

## Database Name=hospital_token_system
## username=root
## password=''
## Functionality
## New user can register
## User Can login and logout
## Generate New token by enter patient Information
## View Posted Receipt
## Print Token Receipt
## User can view/print daily report
## User can view/print Date range report

