<footer id="footer"><!--Footer-->
	<div class="footer-bottom">
			<div class="container">
				<div class="row">
					 <p style="text-transform: uppercase;text-align: center;margin:0px;">Copyright &copy; <?php echo date("Y"); ?> Hospital Token System | <?php echo SIGNATURE ?></p>
					
				</div>
			</div>
		</div>
</footer><!--/Footer-->