	<?php
	session_start(); 
	define("OFFICE_NAME","AI-Fajar Eyes Trust Hospital");
	define("SIGNATURE","<strong>Dedicated To My Father ILYAS AHMAD</strong>| DESIGN AND DEVELOPED BY <strong>MUHAMMAD QASIM CONTACT US: 0323-0479048<strong>");
	
	date_default_timezone_set("Asia/Karachi");
	require_once("../config/Connection_DB.php");
	require_once("../model/User_Model.php");
	require_once("../model/Token_Model.php");
	require_once("../helper/session_functions.php");
  
	$connect_db=new Connection_DB();
	$connection=$connect_db->get_connection();
	$user=new User_Model($connection);
	if(isset($_GET["key"])){
	
		$is_login=is_login($_GET["key"],"user_id");
		
		$url="../controller/User_Controller.php?home=1&key=".$_GET["key"];	
	}else{
		$is_login=false;
		$url="../controller/User_Controller.php?home=1";	
	}


?>
	<header id="header"><!--header-->

		<div class="header_top"><!--header_top-->
			<nav class="navbar navbar-inverse">
			  <div class="container">
			    <div class="navbar-header">
			    
			      <a class='navbar-brand' href='<?php echo $url; ?>'>Hospital Token System </a>
			    </div>
			    	<ul class="nav navbar-nav navbar-right" >
					<?php if(!$is_login){ ?>	
					<li style="padding-top: 0px"> <a href="../controller/User_Controller.php?register=1" style="><i class="fa fa-user"></i> Register</a></li>
					<li style="padding-top: 0px"><a href="../controller/User_Controller.php?login=1"><i class="fa fa-lock"></i> Login</a></li>
					<?php }else { $user_name=get_value_of_current_user($_GET["key"],"user_name");
					?>
					
					


					<li class="dropdown">
				        <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="text-transform: uppercase;"><?php echo $user_name;?>
				        <span class="caret"></span></a>
				        <ul class="dropdown-menu">
				          <li><a href="../controller/Token_Controller.php?report=1&key=<?php echo $_GET["key"];?>"><i class="fa fa-users"></i> Daily Report</a></li>
				         <li style="padding-top: 0px"><a href="../controller/User_Controller.php?logout=1&key=<?php echo $_GET["key"];?>"><i class="fa fa-lock"></i> Logout</a>
				        </ul>
				    </li>
					

					</li><?php	} ?>


				</ul>

			  </div>
			</nav>

		</div><!--/header_top-->
		
		
	
		
	</header><!--/header-->